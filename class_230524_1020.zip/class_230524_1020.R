list.files(pattern = "csv$")

iris[1] # 1차원 벡터? 2차원 객체? 리스트?
iris[, 1] # 데이터프레임 or matrix

df = iris
head(df, 2)

df$aa = 1
df[, "aa"] = 1
head(df, 2)

sum(df$aa)
# 제가 작성한 모든 코드는 Github을 통해 공유드립니다.

unique(df$Species)

df_sub = df[df$Species == "versicolor", ]
head(df_sub)

rownames(df_sub) = NULL
head(df_sub)

colnames(df_sub)[1] = 123
head(df_sub, 2)
# 객체나 변수명이 숫자 또는 특수문자로 시작되면 안됨.
# 2023y -> y2023

# "'asdf'asdfasdf"

df_dia = read.csv("diamonds.csv")
head(df_dia, 2)

df_dia_sub1 = df_dia[(df_dia$cut == "Ideal") & (df_dia$color == "E"), ]
# df_dia_sub1 = df_dia[() & (), ]

condi1 = df_dia$cut == "Ideal"
condi2 = df_dia$color == "E"
df_dia_sub2 = df_dia[condi1 & condi2, ]
head(df_dia_sub2)
# 단일/다중 line 주석 [Ctrl] + [Shift] + [c]

df_dia_sub3 = df_dia[(df_dia$color == "E") | (df_dia$color == "J"), ]
df_dia_sub4 = df_dia[df_dia$color %in% c("E", "J"), ]
head(df_dia_sub3)
head(df_dia_sub4)

getwd()

df_dia_sub4$z
df_dia_sub4[, "z"]
# head(df_dia_sub4[, "z", drop = FALSE], 2)

df_dia[1, ]

df = read.csv("krx_202105_utf8.csv")
head(df, 2)

df_sub = df[df$지수명 == "KRX 300", ]
head(df_sub, 2)

df[df$종가 == max(df$종가), c("지수명", "종가", "날짜")]
df[df$종가 == min(df$종가), c("지수명", "종가", "날짜")]

df[which.max(df$종가), c("지수명", "종가", "날짜")]
# which.max() 최대값의 index를 반환

df = read.csv("iris_missing.csv")
df_sub = head(df)
df_sub
summary(df_sub)

is.na(df_sub$Sepal.Width)
sum(is.na(df_sub$Sepal.Width))

# 각 변수별 결측치 개수 확인
apply(is.na(df_sub), MARGIN = 1, FUN = "sum")
apply(is.na(df_sub), MARGIN = 2, FUN = "sum")
apply(df_sub, MARGIN = 2, FUN = function(x){sum(is.na(x))})

df_sub[is.na(df_sub$Sepal.Width) == FALSE, ]
df_sub[!is.na(df_sub$Sepal.Width), ] # !는 TRUE/FALSE 반전

apply(is.na(df), MARGIN = 2, FUN = "sum")

# install.packages("tidyr")
# install.packages("tidyr_1.2.0.tar.gz", repos = NULL, type = "source")
library("tidyr")
df_sub2 = drop_na(df)
apply(is.na(df_sub2), MARGIN = 2, FUN = "sum")
nrow(df)
nrow(df_sub2)

df_sub3 = na.omit(df)
apply(is.na(df_sub3), MARGIN = 2, FUN = "sum")
nrow(df)
nrow(df_sub3)

mean(df_sub$Sepal.Width)
mean(df_sub$Sepal.Width, na.rm = TRUE)
stat_mean = mean(df_sub$Sepal.Width, na.rm = TRUE)
df_sub[is.na(df_sub$Sepal.Width), "Sepal.Width"] = stat_mean
df_sub



