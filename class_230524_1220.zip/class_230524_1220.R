list.files(pattern = "csv$")

iris[1] # 1차원 벡터? 2차원 객체? 리스트?
iris[, 1] # 데이터프레임 or matrix

df = iris
head(df, 2)

df$aa = 1
df[, "aa"] = 1
head(df, 2)

sum(df$aa)
# 제가 작성한 모든 코드는 Github을 통해 공유드립니다.

unique(df$Species)

df_sub = df[df$Species == "versicolor", ]
head(df_sub)

rownames(df_sub) = NULL
head(df_sub)

colnames(df_sub)[1] = 123
head(df_sub, 2)
# 객체나 변수명이 숫자 또는 특수문자로 시작되면 안됨.
# 2023y -> y2023

# "'asdf'asdfasdf"

df_dia = read.csv("diamonds.csv")
head(df_dia, 2)

df_dia_sub1 = df_dia[(df_dia$cut == "Ideal") & (df_dia$color == "E"), ]
# df_dia_sub1 = df_dia[() & (), ]

condi1 = df_dia$cut == "Ideal"
condi2 = df_dia$color == "E"
df_dia_sub2 = df_dia[condi1 & condi2, ]
head(df_dia_sub2)
# 단일/다중 line 주석 [Ctrl] + [Shift] + [c]

df_dia_sub3 = df_dia[(df_dia$color == "E") | (df_dia$color == "J"), ]
df_dia_sub4 = df_dia[df_dia$color %in% c("E", "J"), ]
head(df_dia_sub3)
head(df_dia_sub4)

getwd()

df_dia_sub4$z
df_dia_sub4[, "z"]
# head(df_dia_sub4[, "z", drop = FALSE], 2)

df_dia[1, ]

df = read.csv("krx_202105_utf8.csv")
head(df, 2)

df_sub = df[df$지수명 == "KRX 300", ]
head(df_sub, 2)

df[df$종가 == max(df$종가), c("지수명", "종가", "날짜")]
df[df$종가 == min(df$종가), c("지수명", "종가", "날짜")]

df[which.max(df$종가), c("지수명", "종가", "날짜")]
# which.max() 최대값의 index를 반환

df = read.csv("iris_missing.csv")
df_sub = head(df)
df_sub
summary(df_sub)

is.na(df_sub$Sepal.Width)
sum(is.na(df_sub$Sepal.Width))

# 각 변수별 결측치 개수 확인
apply(is.na(df_sub), MARGIN = 1, FUN = "sum")
apply(is.na(df_sub), MARGIN = 2, FUN = "sum")
apply(df_sub, MARGIN = 2, FUN = function(x){sum(is.na(x))})

df_sub[is.na(df_sub$Sepal.Width) == FALSE, ]
df_sub[!is.na(df_sub$Sepal.Width), ] # !는 TRUE/FALSE 반전

apply(is.na(df), MARGIN = 2, FUN = "sum")

# install.packages("tidyr")
# install.packages("tidyr_1.2.0.tar.gz", repos = NULL, type = "source")
library("tidyr")
df_sub2 = drop_na(df)
apply(is.na(df_sub2), MARGIN = 2, FUN = "sum")
nrow(df)
nrow(df_sub2)

df_sub3 = na.omit(df)
apply(is.na(df_sub3), MARGIN = 2, FUN = "sum")
nrow(df)
nrow(df_sub3)

mean(df_sub$Sepal.Width)
mean(df_sub$Sepal.Width, na.rm = TRUE)
stat_mean = mean(df_sub$Sepal.Width, na.rm = TRUE)
df_sub[is.na(df_sub$Sepal.Width), "Sepal.Width"] = stat_mean
df_sub

class(df_sub)
class(df_sub$Sepal.Length)

# 모든 변수의 자료형 확인
sapply(df_sub, FUN = "class")
# sapply()는 기본적으로 열기준 연산을 하며
# apply(MARGIN = 2)와 매우 유사.

as.numeric("123124")
as.character(12324)

# substr(as.character(12324), 1, 3)
substr(12324, 1, 3)
substr(12324, start = 1, stop = 3)

df_dia = read.csv("diamonds.csv")
head(df_dia, 2)

table(df_dia$color)
df_dia_col_tbl = as.data.frame(table(df_dia$color))
df_dia_col_tbl

class(df_dia_col_tbl$Var1)
df_dia_col_tbl[, "Var1"] = as.character(df_dia_col_tbl$Var1)
df_dia_col_tbl
class(df_dia_col_tbl$Var1)


df = read.csv("bike.csv")
unique(df$season) # 중복제거
length(unique(df$season)) # 고유한 원소 개수
table(df$season)
table(df$season, df$holiday)
table(aa = df$season, bb = df$holiday)
table(df[, c("season", "holiday")])
prop.table(table(df$season))
prop.table(table(df[, c("season", "holiday")]), margin = 1)
prop.table(table(df[, c("season", "holiday")]), margin = 2)

head(df)

df_sub = df[4:6, c("casual", "registered", "count")]
df_sub

unique(df_sub) # 데이터프레임에 사용할 경우 중복행 제외

df = airquality
head(df, 2)
aggregate(data = df, Wind ~ Month, FUN = "mean")

aggregate(data = df[, c("Wind", "Temp", "Month")], 
          . ~ Month, FUN = "mean")
# . 는 선언된 변수를 제외한 나머지 변수

df[, "new_col"] = 123
df[, "new_col2"] = df$Wind * df$Temp
head(df)

# as.numeric("a")
# library("data.table")

df_s = data.frame(obs = 1:3,
                  c1 = c("aaa", "abc", "ccc"),
                  c2 = c("a-b-c", "a", "b-c"))
df_s

nchar(df_s$c2)
# yyyy-mm-dd

df_s[nchar(df_s$c2) < 5, ]
df_s

df_s$c1[df_s$c1 != "a"]
df_s$c1[df_s$c1 != "aaa"]

gsub(pattern = "a", replacement = "", df_s$c1) # "a"를 제거
gsub(pattern = "a", replacement = "@", df_s$c1)

grep(pattern = "b", df_s$c1) # 패턴을 만족하는 원소의 인덱스
grep(pattern = "b", df_s$c1, value = TRUE)
df_s[grep(pattern = "b", df_s$c1), ]

strsplit(df_s$c2, split = "-")
# install.packages("splitstackshape")
library("splitstackshape")
df_s_split = cSplit(df_s, splitCols = "c2", sep = "-")
class(df_s_split)
df_s_split = as.data.frame(df_s_split)
class(df_s_split)

substr("abcdefg", start = 2, stop = 4)

df_bike = read.csv("bike.csv")
head(df_bike, 2)

substr(df_bike$datetime, start = 1, stop = 4)

grep(pattern = "b", df_s$c1)
grepl(pattern = "b", df_s$c1)
!grepl(pattern = "b", df_s$c1)

df_s[grepl(pattern = "b", df_s$c1), ]
df_s[!grepl(pattern = "b", df_s$c1), ]

# 2set - 4H
# 2시간, 첫 시간은 여러분이 문제를 풉니다.
#        둘째시간은 제가 풀이를 합니다. + 질의응답

library("lubridate")
# as.Date() - 기본함수
as_date("2077-01-01") # lubridate 함수
as_date("2077년 01월 01일")
as_date("1/1 2077", format = "%m/%d %Y")
?strptime

as_date(12345, origin = "2000-01-01")
# 2000년 1월 1일부터 12345일 경과된 날짜

as_datetime(12345, origin = "2000-01-01")
# 12345초 경과된 시각


head(df_bike)
df_bike2 = df_bike[, c("datetime", "temp")]
head(df_bike2)

df_bike2[, "year" ] = year(df_bike2$datetime)
df_bike2[, "month"] = month(df_bike2$datetime)
df_bike2[, "hour" ] = hour(df_bike2$datetime)
df_bike2[, "wday1"] = wday(df_bike2$datetime)
df_bike2[, "wday2"] = wday(df_bike2$datetime, label = TRUE)
df_bike2[, "wday3"] = wday(df_bike2$datetime, week_start = 1)
df_bike2[, "wday4"] = wday(df_bike2$datetime, 
                           week_start = 1,
                           label = TRUE)
df_bike2[, "is_wend"] = ifelse(df_bike2$wday3 > 5, 1, 0)
head(df_bike2)

df_bike2[1:4, "wday2"]
df_bike2[1:4, "wday4"]

df_bike2[, "date"] = as_date(df_bike2$datetime)
head(df_bike2, 3)

df_temp_agg = aggregate(data = df_bike2, temp ~ date, FUN = "mean")
head(df_temp_agg)

library("dplyr")
lag(df_temp_agg$temp, n = 2)[1:10]

df_temp_agg[, "temp_l1"] = lag(df_temp_agg$temp, n = 1)
df_temp_agg[, "temp_diff1"] = df_temp_agg$temp - df_temp_agg$temp_l1
head(df_temp_agg)

library("reshape2")
set.seed(123)
df = data.frame(Obs = 1:4,
                A = sample(10:99, size = 4),
                B = sample(10:99, size = 4),
                c = sample(10:99, size = 4),
                D = sample(10:99, size = 4))
df

df_melt = melt(data = df, id.vars = "Obs",
               variable.name = "Group", value.name = "Count")
head(df_melt)
df_melt[12, 3] = NA

dcast(data = df_melt, formula = Obs ~ Group, value.var = "Count")

# rbind()
# cbind()
cbind(head(iris, 2), 
      head(iris, 3))

cbind(tail(iris, 3), 
      head(iris, 3))

head(df_bike2, 2)

df_bike2_join = left_join(df_bike2, df_temp_agg, 
                          by = c("date" = "date"))
head(df_bike2_join)

head(df_temp_agg, 2)
colnames(df_temp_agg)[2] = "temp_mean"
df_bike2_join = left_join(df_bike2, df_temp_agg, 
                          by = c("date" = "date"))
head(df_bike2_join, 2)


aggregate(data = iris, Sepal.Length ~ Species,
          FUN = function(x){round(mean(x), 1)})

x = iris[iris$Species == "setosa", "Sepal.Length"]
round(mean(x), 1)


df_ss = data.frame(obs = 1:4,
                   str = c("aa", "ab", "dd", "ba"))
df_ss
df_ss[grepl(pattern = "a|b", df_ss$str), ]
sum(grepl(pattern = "a|b", df_ss$str))
