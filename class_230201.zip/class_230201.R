df = iris
df[1:2, ]
df[, 1]
df[1] # xxx
df[1:5, 1, drop = FALSE]

df[, "col1"] = 3
df$col2 = 33
head(df)

list.files()

df = read.csv("krx_202105_utf8.csv",
              fileEncoding = "utf-8")
head(df, 2)

df_sub = df[df$지수명 == "KRX 300", ]
df_sub

df[df$종가 == max(df$종가), c("지수명", "종가", "날짜")]
df[df$종가 == min(df$종가), c("지수명", "종가", "날짜")]

# 최대값이 여러개인 경우 가장 앞에 있는 최대값의 index
df[which.max(df$종가), c("지수명", "종가", "날짜")]
df[which.min(df$종가), c("지수명", "종가", "날짜")]

head(df, 2)
df_sub = df[, 1:3]
head(df_sub)

df_sub2 = df_sub[(df_sub$지수명 == "KRX 300") | (df_sub$지수명 == "KRX 100"), ]
df_sub2 = df_sub[df_sub$지수명 %in% c("KRX 300", "KRX 100"), ]
df_sub2

TRUE
FALSE
TRUE + FALSE
!FALSE
!c(TRUE, FALSE)

df = read.csv("iris_missing.csv")
df_sub = head(df)
summary(df_sub)

is.na(NA)
is.na(123)

is.na(c(123, NA, 345))
sum(is.na(c(123, NA, 345))) # 결측치의 개수를 셈함.

sum(is.na(df$Sepal.Width)) # Sepal.Width 변수의 결측치 개수 확인.

apply(df, MARGIN = 2, FUN = function(x){sum(is.na(x))})
sapply(df, FUN = function(x){sum(is.na(x))})

# install.packages("psych")
library("psych")
df_des = describe(df)
df_des[, "na_cnt"] = nrow(df) - df_des$n
df_des

library("data.table")
df = fread("iris_missing.csv", data.table = FALSE)
head(df, 2)

mean(df$Sepal.Width)
mean(df$Sepal.Width, na.rm = TRUE)

library("tidyr")
df_notna = drop_na(df)
nrow(df_notna)
sapply(df_notna, FUN = function(x){sum(is.na(x))})

# Sepal.Width 변수에 결측치가 있는 row를 제외
df_notna2 = df[is.na(df$Sepal.Width) == FALSE, ] 
sapply(df_notna2, FUN = function(x){sum(is.na(x))})

class(df)
as.numeric(c("123", "adf", "456"))

table(df$Species)
df_tbl = as.data.frame(table(df$Species))
df_tbl
class(df_tbl$Var1)
df_tbl[, "Var1"] = as.character(df_tbl$Var1)
class(df_tbl$Var1)

df = read.csv("bike.csv")
head(df, 2)
unique(df$season)
length(unique(df$season))

library("dplyr")
n_distinct(df$season)

table(df$season, df$holiday)
table(df[, c("season", "holiday")])
table(v1 = df$season, v2 = df$holiday)

df = airquality
aggregate(data = df, Wind ~ Month, FUN = "mean")
# Month별 Wind의 평균(mean)
# SELECT AVG(Wind) AS Wind, Month FROM df GROUP BY Month
aggregate(data = df, Wind ~ Month, FUN = mean)
# 표준평가, 비표준평가

list.files()

df = read.csv("diamonds.csv")
head(df, 2)

df[, "is_color_E"] = ifelse(df$color == "E", yes = 1, no = 0)
df[, "is_color_E2"] = (df$color == "E") + 0
df[, "is_color_E3"] = (df$color == "E") * 1
head(df, 2)
table(df$color, df$is_color_E)

df[, "color2"] = ifelse(df$color == "D", yes = "DDDD", no = df$color)
table(df[, c("color", "color2")])

head(df, 2)
df[, "volumn"] = df$x * df$y * df$z
head(df, 2)

vec = c("asdf123", "aa456", "123ggg")
gsub(pattern = "123", replacement = "", vec)
gsub(pattern = "ggg", replacement = "", vec)
gsub(pattern = "a|1", replacement = "", vec) # a 또는 1

gsub(pattern = "[0-9]", replacement = "", vec) # 숫자를 제거

substr(vec, start = 1, stop = 3)
substr(vec, start = 3, stop = 5)
# Excel의 mid() 함수와 유사

vec2 = c("aaa-222", "aa-bb-cc", "hhh")
strsplit(vec2, split = "-")
unlist(lapply(strsplit(vec2, split = "-"), FUN = "[", 1))

2 + 3
`+`(2, 3)

vec[2]
`[`(vec, 2)

library("splitstackshape")
dt_spl = cSplit(data.frame(col1 = vec2), splitCols = "col1", sep = "-")
class(dt_spl)
df_spl = as.data.frame(dt_spl)
class(df_spl)

# is. 접두사: 객체의 class(또는 type) 검사, 결과는 TRUE/FALSE
# as. 접두사: 객체를 특정 class(또는 type)으로 변환
# ex) as.data.frame() - 데이터프레임으로 변환

library("lubridate")
?as.Date
?as_date
?as_datetime

# %Y: 4자리 연도
# %y: 2자리 연도
as_date(x = "1/1 2077", format = "%m/%d %Y")
as_date(x = "1/1 2077", format = "%m/%d %Y", tz = "UTC")
?as_date

sessionInfo()
# install.packages("lubridate")
df_bike = read.csv("bike.csv")
head(df_bike)

df_bike_sub = df_bike[, 1:2]
df_bike_sub[, "ymd_h"] = substr(df_bike_sub$datetime,
                                start = 1, stop = 13)
df_bike_sub[, "dt2"] = ymd_h(df_bike_sub$ymd_h)
head(df_bike_sub, 2)
sapply(df_bike_sub, FUN = "class")
df_bike_sub[, "wday"] = wday(df_bike_sub$dt2,
                             week_start = 1)
head(df_bike_sub, 2)

df_sub = df_bike[, c("datetime", "temp")]
df_sub[, "date"] = as_date(df_sub$datetime)
head(df_sub, 2)

df_sub_agg = aggregate(data = df_sub, temp ~ date, FUN = "max")
head(df_sub_agg, 2)

library("dplyr")
df_sub_agg[, "temp_l1"] = lag(df_sub_agg$temp, n = 1)
df_sub_agg[, "temp_diff_1"] = df_sub_agg$temp - df_sub_agg$temp_l1
head(df_sub_agg, 3)

?aggregate

library("reshape2")
set.seed(123)
df = data.frame(Obs = 1:4,
                A = sample(10:99, size = 4),
                B = sample(10:99, size = 4),
                C = sample(10:99, size = 4))
df

df_melt = melt(data = df, id.vars = "Obs",
               variable.name = "Group", value.name = "Count")
df_melt

dcast(data = df_melt, formula = Obs ~ Group,
      value.var = "Count")

df[, "var_new"] = 1
df

df = cbind(new = 23,
           df)
df

head(df_bike, 2)

df_bike[, "date"] = as_date(df_bike$datetime)
df_bike_agg1 = aggregate(data = df_bike, casual ~ date, FUN = "sum")
df_bike_agg2 = aggregate(data = df_bike, registered ~ date, FUN = "sum")
head(df_bike_agg1)

df_bike_agg_join = inner_join(x = df_bike_agg1, y = df_bike_agg2,
                              by = c("date" = "date"))
head(df_bike_agg_join, 2)

#### ML ####
df = read.csv("iris_missing.csv")
head(df, 2)

sapply(df, FUN = function(x){sum(is.na(x))})
# Q1. Sepal.Length 변수를 제외한 나머지 변수의 결측치는
#     해당 변수의 평균값으로 대치하시오.
df[is.na(df$Sepal.Width ), "Sepal.Width" ] = mean(df$Sepal.Width, na.rm = TRUE)
df[is.na(df$Petal.Length), "Petal.Length"] = mean(df$Petal.Length, na.rm = TRUE)
df[is.na(df$Petal.Width ), "Petal.Width" ] = mean(df$Petal.Width, na.rm = TRUE)
sapply(df, FUN = function(x){sum(is.na(x))})

# Q2. Sepal.Length 변수의 결측치는 선형회귀를 활용하여
#     다중대치를 실시하시오.
# ※ 독립변수는 Sepal.Width, Petal.Length, Petal.Width
df_train = df[is.na(df$Sepal.Length) == FALSE, -5] # 관측치
df_test  = df[is.na(df$Sepal.Length)         , -5] # 결측치

model = lm(Sepal.Length ~ . , data = df_train)

pred = predict(model, df_test)

df_test[, "Sepal.Length"] = pred
df_notna = rbind(df_train, df_test)
head(df_notna, 2)

df = read.csv("iris.csv")
df = df[, -5]
head(df, 2)

library("caTools")
set.seed(123)
idx_train = sample.split(Y = df$PetalWidth, SplitRatio = 0.7) # train 70%
length(idx_train)
sum(idx_train) # 106 개의 row가 train set으로 될 예정

df_train = df[ idx_train, ]
df_test  = df[!idx_train, ]
head(df_train, 2)
#   SepalLength SepalWidth PetalLength PetalWidth
# 1         5.1        3.5         1.4        0.2
# 3         4.7        3.2         1.3        0.2

library("caret")
model_minmax = preProcess(df_train, method = "range")
df_train_nor = predict(model_minmax, df_train)
df_test_nor  = predict(model_minmax, df_test)
head(df_train_nor, 2)
head(df_test_nor, 2)


df1 = data.frame(v1 = 1:5,
                 v2 = 3:7,
                 v3 = 5:9)
df2 = data.frame(v1 = 1:2,
                 v2 = 3:4,
                 v3 = 100:101)
df1
df2

df_bind = rbind(df1, df2)
model_mm1 = preProcess(df_bind, method = "range")
df_bind_nor = predict(model_mm1, df_bind)
df_bind_nor

model_mm2 = preProcess(df1, method = "range")
df1_nor = predict(model_mm2, df1)
df1_nor
predict(model_mm2, df2)

# apply(): 축방향 연산
#          MARGIN = 1 : row 방향으로 FUN 인자에 할당된 함수 적용
#          MARGIN = 2 : col 방향으로 FUN 인자에 할당된 함수 적용
# sapply(): col 방향 연산. 즉, apply(MARGIN = 2) 와 매우 유사
#  ※ simplified apply function

# grep(): pattern인자에 지정된 규칙에 해당하는 텍스트의 index 또는
#         해당 규칙과 매칭이되는 원소를 반환(value = TRUE)
# grepl(): pattern인자에 지정된 규칙에 해당하는 텍스트의 index 위치에
#          TRUE를 반환하고 나머지 index 위치에는 FALSE를 반환
#  ※ logical output

