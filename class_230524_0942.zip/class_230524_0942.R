list.files(pattern = "csv$")

iris[1] # 1차원 벡터? 2차원 객체? 리스트?
iris[, 1] # 데이터프레임 or matrix

df = iris
head(df, 2)

df$aa = 1
df[, "aa"] = 1
head(df, 2)

sum(df$aa)
# 제가 작성한 모든 코드는 Github을 통해 공유드립니다.

unique(df$Species)

df_sub = df[df$Species == "versicolor", ]
head(df_sub)

rownames(df_sub) = NULL
head(df_sub)

colnames(df_sub)[1] = 123
head(df_sub, 2)
# 객체나 변수명이 숫자 또는 특수문자로 시작되면 안됨.
# 2023y -> y2023

# "'asdf'asdfasdf"

df_dia = read.csv("diamonds.csv")
head(df_dia, 2)

df_dia_sub1 = df_dia[(df_dia$cut == "Ideal") & (df_dia$color == "E"), ]
# df_dia_sub1 = df_dia[() & (), ]

condi1 = df_dia$cut == "Ideal"
condi2 = df_dia$color == "E"
df_dia_sub2 = df_dia[condi1 & condi2, ]
head(df_dia_sub2)
# 단일/다중 line 주석 [Ctrl] + [Shift] + [c]

df_dia_sub3 = df_dia[(df_dia$color == "E") | (df_dia$color == "J"), ]
df_dia_sub4 = df_dia[df_dia$color %in% c("E", "J"), ]
head(df_dia_sub3)
head(df_dia_sub4)

getwd()
